const ADD = {
  SUCCESS: "ADD_TO_CART_SUCCESS",
};

export const CartActionTypes = {
  ADD_TO_CART: ADD,
  REMOVE_FROM_CART: 'REMOVE_FROM_CART',
  CLEAR: 'CLEAR_CART',
};
