import React from "react";

function Error403() {
  return (
    <div className="center-form">
      <div className="container text-center">
        <div className="w-50 m-auto">
          <h3>Error 403. Access Denied</h3>
        </div>
      </div>
    </div>
  );
}

export default Error403;
